#!/bin/bash

cd /var/lib/neo4j/import
neo4j-admin import --database neo4j --force \
	--nodes=Product=product_with_rate_price.csv \
	--nodes=Reviewer=reviewers.csv \
	--relationships=isSimilarTo=Product_isSimilarTo_Product.csv \
	--relationships=alsoBuy=Product_alsoBuy_Product.csv \
	--relationships=alsoView=Product_alsoView_Product.csv \
	--relationships=sameRates=User_usu_User_10000.csv \
	--relationships=rates=Reviewer_rates_Product.csv
chown -R neo4j /data
chown -R neo4j /var/lib/neo4j/data
chown -R neo4j /logs
